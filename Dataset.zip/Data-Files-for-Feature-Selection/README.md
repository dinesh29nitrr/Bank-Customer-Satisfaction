# Please Download Working Files From Here

Paribas Claim Management Dataset: https://www.kaggle.com/c/bnp-paribas-cardif-claims-management/data

Note: These files were too large that's why I had to provide external link.

